
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { 
  Cpu, Play, Pause, Atom, Network, Database,
  AlertTriangle, Search, Square, RefreshCw,
  Menu, X, BarChart2
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';

import { AgentType, ResearchState, AgentLog, ResearchTask, KnowledgeFact, ExperimentSpec, ResearchBranch } from './types';
import { 
    orchestratePlan, 
    executeAgentTask, 
    generateSimulationCode, 
    synthesizeResearch, 
    reviewTaskOutput,
    evaluateProgress
} from './services/geminiService';
import { initPyodide, runPythonSimulation } from './services/pyodideService';
import LogStream from './components/LogStream';
import SimulationViewer from './components/SimulationViewer';
import { TaskTree } from './components/TaskTree';
import NotebookCell from './components/NotebookCell';
import SpecViewer from './components/SpecViewer';

const MAX_ITERATIONS = 2;

const INITIAL_STATE: ResearchState = {
  isActive: false,
  originalPrompt: '',
  branches: [],
  knowledgeBank: [],
  logs: [],
  finalSynthesis: '',
  progress: 0,
  isPyodideReady: false,
};

const App: React.FC = () => {
  const [state, setState] = useState<ResearchState>(INITIAL_STATE);
  const [userInput, setUserInput] = useState('');
  const [kbFilter, setKbFilter] = useState('');
  
  // Mobile State
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileDataOpen, setMobileDataOpen] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const processingRef = useRef(false); 

  // Load Pyodide on Mount
  useEffect(() => {
    const load = async () => {
        const ready = await initPyodide();
        setState(prev => ({ ...prev, isPyodideReady: ready }));
    };
    load();
  }, []);

  // Auto-scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [state.finalSynthesis, state.logs.length, state.knowledgeBank.length, state.branches]);

  const addLog = useCallback((agentName: string, message: string, type: AgentLog['type'] = 'info', branchId?: string) => {
    setState(prev => ({
      ...prev,
      logs: [...prev.logs, {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now(),
        agentName,
        message,
        type,
        branchId
      }]
    }));
  }, []);

  // --- SMART SCHEDULER LOGIC (Heuristic) ---
  const getNextTask = (branches: ResearchBranch[]): { task: ResearchTask, branch: ResearchBranch } | null => {
      const activeBranches = branches.filter(b => b.status === 'active');
      const finishedTaskIds = new Set<string>();
      branches.forEach(b => b.tasks.forEach(t => {
          if (t.status === 'done') finishedTaskIds.add(t.id);
      }));

      let candidates: { task: ResearchTask, branch: ResearchBranch, score: number }[] = [];

      for (const branch of activeBranches) {
          for (const task of branch.tasks) {
              if (task.status === 'pending' || task.status === 'refining') {
                  const allDepsMet = task.dependencies.every(depId => finishedTaskIds.has(depId));
                  
                  if (allDepsMet) {
                      let dependentCount = 0;
                      branches.forEach(b => b.tasks.forEach(t => {
                          if (t.dependencies.includes(task.id)) dependentCount++;
                      }));

                      const score = (task.priority * 10) + (dependentCount * 5) - (task.iterationCount * 5);
                      candidates.push({ task, branch, score });
                  }
              }
          }
      }

      if (candidates.length === 0) return null;
      candidates.sort((a, b) => b.score - a.score);
      return { task: candidates[0].task, branch: candidates[0].branch };
  };

  // --- THE MAIN AUTONOMOUS LOOP ---
  const processExecutionLoop = async () => {
      if (processingRef.current) return;
      processingRef.current = true;

      try {
        while (true) {
            let currentState: ResearchState | null = null;
            setState(prev => { currentState = prev; return prev; });
            
            if (!currentState || !currentState.isActive) break;

            const nextItem = getNextTask(currentState.branches);
            
            if (!nextItem) {
                const hasActivePending = currentState.branches
                  .filter(b => b.status === 'active')
                  .some(b => b.tasks.some(t => t.status === 'pending' || t.status === 'refining'));

                const hasPausedPending = currentState.branches
                  .filter(b => b.status === 'paused')
                  .some(b => b.tasks.some(t => t.status === 'pending' || t.status === 'refining'));

                if (!hasActivePending && !hasPausedPending) {
                    break; 
                } else if (hasPausedPending && !hasActivePending) {
                    addLog('SYSTEM', 'All active vectors converged. Remaining vectors are PAUSED.', 'warning');
                    break;
                } else {
                    addLog('SYSTEM', 'Deadlock detected or awaiting resolution. Idling...', 'warning');
                    await new Promise(r => setTimeout(r, 3000));
                    break; 
                }
            }

            const { task, branch } = nextItem;

            addLog(task.assignedTo, `Starting [P${task.priority}]: ${task.description}`, 'info', branch.id);
            
            let output = "";
            let urls: string[] = [];
            let taskSuccess = false;
            let pythonCode = "";
            let simData: any[] = [];
            let simScenarios: string[] = [];
            let experimentSpec: ExperimentSpec | undefined = undefined;

            setState(prev => ({
                ...prev,
                branches: prev.branches.map(b => b.id === branch.id ? {
                    ...b,
                    tasks: b.tasks.map(t => t.id === task.id ? { ...t, status: 'active' } : t)
                } : b)
            }));

            if (task.assignedTo === AgentType.SIMULATOR || task.assignedTo === AgentType.ARCHITECT) {
                addLog(AgentType.SIMULATOR, `Analyzing computational complexity...`, 'data', branch.id);
                
                const previousCode = task.pythonCode;
                const simGen = await generateSimulationCode(task.description, currentState.knowledgeBank, previousCode);
                
                if (simGen.type === 'CODE' && simGen.code) {
                    pythonCode = simGen.code;
                    simScenarios = simGen.scenarios || [];
                    addLog(AgentType.SIMULATOR, `Running "Toy Model" Simulation (Pyodide)...`, 'data', branch.id);
                    try {
                        simData = await runPythonSimulation(simGen.code);
                        output = `**Simulation Complete.**\nExecuted Python Simulation. Generated ${simData.length} data points.`;
                        taskSuccess = true;
                    } catch (err) {
                        output = `Simulation Failed: ${err}`;
                        addLog(AgentType.SIMULATOR, 'Simulation crashed.', 'error', branch.id);
                    }
                } else if (simGen.type === 'SPEC' && simGen.spec) {
                    experimentSpec = simGen.spec;
                    output = `**Architecture Specification Generated.**\nComplexity: ${experimentSpec.complexity}.`;
                    addLog(AgentType.ARCHITECT, `Generated Spec for ${experimentSpec.title}`, 'warning', branch.id);
                    taskSuccess = true;
                }
            } else {
                let iterations = 0;
                let currentFeedback = undefined;

                while (iterations <= MAX_ITERATIONS && !taskSuccess) {
                     const res = await executeAgentTask(task, currentState.knowledgeBank, currentFeedback);
                     
                     setState(prev => ({
                        ...prev,
                        branches: prev.branches.map(b => b.id === branch.id ? {
                            ...b,
                            tasks: b.tasks.map(t => t.id === task.id ? { ...t, status: 'reviewing' } : t)
                        } : b)
                    }));

                     const critique = await reviewTaskOutput(task, res.content);
                     
                     if (critique.approved) {
                         output = res.content;
                         urls = res.urls;
                         taskSuccess = true;
                         addLog('CRITIC', `Approved (${critique.score}/100)`, 'success', branch.id);
                     } else {
                         iterations++;
                         currentFeedback = critique.feedback;
                         addLog('CRITIC', `Reject: ${critique.feedback}`, 'warning', branch.id);
                         setState(prev => ({
                            ...prev,
                            branches: prev.branches.map(b => b.id === branch.id ? {
                                ...b,
                                tasks: b.tasks.map(t => t.id === task.id ? { ...t, status: 'refining', iterationCount: iterations } : t)
                            } : b)
                        }));
                     }
                }
                if (!taskSuccess) output = "Task failed to converge after max iterations.";
            }

            setState(prev => ({
                ...prev,
                branches: prev.branches.map(b => b.id === branch.id ? {
                    ...b,
                    tasks: b.tasks.map(t => t.id === task.id ? { 
                        ...t, 
                        status: 'done',
                        result: output,
                        groundingUrls: urls,
                        pythonCode: pythonCode || undefined,
                        simulationData: simData.length > 0 ? simData : undefined,
                        simulationScenarios: simScenarios.length > 0 ? simScenarios : undefined,
                        experimentSpec: experimentSpec
                    } : t)
                } : b)
            }));

            if (taskSuccess) {
                addLog('MANAGER', `Evaluating progress & re-prioritizing...`, 'data', branch.id);
                const allTasksRef = currentState.branches.flatMap(b => b.tasks);
                const evaluation = await evaluateProgress(currentState.originalPrompt, task, output, currentState.knowledgeBank, allTasksRef);

                if (evaluation.newFacts.length > 0) {
                    setState(prev => ({ ...prev, knowledgeBank: [...prev.knowledgeBank, ...evaluation.newFacts] }));
                    addLog('MANAGER', `Absorbed ${evaluation.newFacts.length} new axioms.`, 'success', branch.id);
                }

                if (evaluation.reprioritize.length > 0) {
                    addLog('MANAGER', `Adjusting priorities for ${evaluation.reprioritize.length} tasks.`, 'warning', branch.id);
                    setState(prev => ({
                        ...prev,
                        branches: prev.branches.map(b => ({
                            ...b,
                            tasks: b.tasks.map(t => {
                                const update = evaluation.reprioritize.find(r => r.taskId === t.id);
                                return update ? { ...t, priority: update.newPriority } : t;
                            })
                        }))
                    }));
                }

                if (evaluation.newTasks.length > 0 && !evaluation.stopBranch) {
                    addLog('MANAGER', `Adding +${evaluation.newTasks.length} tasks to queue.`, 'info', branch.id);
                    setState(prev => ({
                        ...prev,
                        branches: prev.branches.map(b => b.id === branch.id ? {
                            ...b,
                            tasks: [...b.tasks, ...evaluation.newTasks.map(t => ({
                                ...t, 
                                id: Math.random().toString(36).substr(2, 9), 
                                status: 'pending' as const, 
                                iterationCount: 0, 
                                critiques: []
                            }))]
                        } : b)
                    }));
                } else if (evaluation.stopBranch) {
                    addLog('MANAGER', `Branch ${branch.name} marked as converged.`, 'success', branch.id);
                    setState(prev => ({
                        ...prev,
                        branches: prev.branches.map(b => b.id === branch.id ? { ...b, status: 'completed' } : b)
                    }));
                }
            }
        }
      } catch (e) {
          console.error(e);
          addLog('SYSTEM', 'Loop Error', 'error');
      } finally {
          processingRef.current = false;
          setState(prev => {
               const allActiveDone = prev.branches
                 .filter(b => b.status === 'active')
                 .every(b => b.tasks.every(t => t.status === 'done'));
                 
               if (allActiveDone && prev.isActive && prev.branches.some(b => b.status === 'active')) {
                   finishResearch(prev);
               }
               return prev;
          });
      }
  };

  const finishResearch = async (finalState: ResearchState) => {
      addLog('SYSTEM', 'All priority vectors converged. Synthesizing final compendium...', 'info');
      const synthesis = await synthesizeResearch(finalState.originalPrompt, finalState.knowledgeBank);
      setState(prev => ({ ...prev, isActive: false, finalSynthesis: synthesis, progress: 100 }));
      addLog('SYSTEM', 'Research Complete.', 'success');
  };

  const handleStartResearch = async () => {
    if (!userInput.trim()) return;
    if (!state.isPyodideReady) {
        addLog('SYSTEM', 'Wait for Python Runtime...', 'warning');
        return;
    }

    setState({ ...INITIAL_STATE, isActive: true, originalPrompt: userInput, isPyodideReady: true });
    addLog('SYSTEM', 'Booting Colossus v6.0 (Smart Scheduler Enabled)', 'info');

    try {
      addLog('ORCHESTRATOR', 'Generating Priority Graph...', 'info');
      const branches = await orchestratePlan(userInput);
      
      setState(prev => ({ ...prev, branches, progress: 5 }));
      addLog('ORCHESTRATOR', `Plan locked. ${branches.length} Vectors.`, 'success');
      setTimeout(processExecutionLoop, 100);
    } catch (error) {
      console.error(error);
      addLog('SYSTEM', `Critical Initialization Failure: ${error}`, 'error');
      setState(prev => ({ ...prev, isActive: false }));
    }
  };

  const handleEmergencyStop = () => {
      addLog('SYSTEM', 'USER INITIATED EMERGENCY HALT.', 'error');
      processingRef.current = false; 
      setState(prev => ({ ...prev, isActive: false }));
  };

  useEffect(() => {
      if (state.isActive && !processingRef.current) {
          const timer = setTimeout(() => processExecutionLoop(), 1000);
          return () => clearTimeout(timer);
      }
  }, [state.isActive, state.branches]);

  const toggleBranchStatus = (branchId: string) => {
      setState(prev => {
          const newBranches = prev.branches.map(b => {
              if (b.id === branchId) {
                  const newStatus = b.status === 'paused' ? 'active' : 'paused';
                  addLog('SYSTEM', `${newStatus === 'paused' ? 'Pausing' : 'Resuming'} vector: ${b.name}`, 'info');
                  return { ...b, status: newStatus as any };
              }
              return b;
          });
          return { ...prev, branches: newBranches };
      });
  };

  const handleReRunSimulation = async (taskId: string, branchId: string, newCode: string) => {
      addLog(AgentType.SIMULATOR, 'Manual Override: Re-running local simulation...', 'info', branchId);
      try {
          const data = await runPythonSimulation(newCode);
          setState(prev => ({
              ...prev,
              branches: prev.branches.map(b => b.id === branchId ? {
                  ...b,
                  tasks: b.tasks.map(t => t.id === taskId ? { ...t, pythonCode: newCode, simulationData: data } : t)
              } : b)
          }));
          addLog(AgentType.SIMULATOR, 'Override successful. Updating visuals.', 'success', branchId);
      } catch (e) {
          addLog(AgentType.SIMULATOR, `Override failed: ${e}`, 'error', branchId);
      }
  };

  const getActiveSimulation = () => {
      for (const branch of state.branches) {
          for (const task of branch.tasks) {
              if (task.simulationData && task.simulationData.length > 0) {
                  return { data: task.simulationData, scenarios: task.simulationScenarios, title: task.description };
              }
          }
      }
      return { data: [], scenarios: [], title: '' };
  };

  const { data: simData, scenarios: simScenarios, title: simTitle } = getActiveSimulation();

  const filteredKnowledge = state.knowledgeBank.filter(k => 
      k.content.toLowerCase().includes(kbFilter.toLowerCase()) || 
      k.sourceAgent.toLowerCase().includes(kbFilter.toLowerCase())
  );

  return (
    <div className="flex flex-col md:flex-row h-screen w-full bg-colossus-900 text-gray-200 overflow-hidden relative">
      
      {/* MOBILE HEADER */}
      <div className="md:hidden h-14 bg-colossus-800 border-b border-colossus-700 flex items-center justify-between px-4 z-20 shrink-0">
          <button onClick={() => setMobileMenuOpen(true)} className="p-2 text-gray-400 hover:text-white">
              <Menu className="w-6 h-6" />
          </button>
          <span className="font-bold text-white tracking-tight flex items-center gap-2">
              <Network className="w-4 h-4 text-colossus-accent" /> COLOSSUS
          </span>
          <button onClick={() => setMobileDataOpen(true)} className="p-2 text-gray-400 hover:text-colossus-accent relative">
              <BarChart2 className="w-6 h-6" />
              {simData.length > 0 && <span className="absolute top-2 right-2 w-2 h-2 bg-colossus-accent rounded-full animate-pulse" />}
          </button>
      </div>

      {/* LEFT SIDEBAR (Navigation/Tasks) */}
      {/* Mobile Overlay */}
      {mobileMenuOpen && (
          <div className="fixed inset-0 bg-black/80 z-30 md:hidden backdrop-blur-sm" onClick={() => setMobileMenuOpen(false)} />
      )}
      
      <div className={`
          fixed inset-y-0 left-0 z-40 w-4/5 max-w-xs bg-colossus-800 border-r border-colossus-700 transform transition-transform duration-300 ease-in-out
          md:relative md:translate-x-0 md:w-80 md:flex md:flex-col md:z-auto
          ${mobileMenuOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}
      `}>
        <div className="hidden md:flex p-5 border-b border-colossus-700 items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-tr from-colossus-accent to-blue-600 rounded-md flex items-center justify-center shadow-lg shadow-colossus-accent/20">
            <Network className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold text-lg tracking-tight text-white">COLOSSUS</h1>
            <div className="flex items-center gap-2">
                <p className="text-[10px] font-mono text-colossus-accent uppercase">Scheduler v6.1</p>
                {state.isPyodideReady ? (
                    <span className="w-2 h-2 bg-green-500 rounded-full" title="Runtime Ready"></span>
                ) : (
                    <span className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse" title="Booting Runtime..."></span>
                )}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between md:hidden p-4 border-b border-colossus-700">
             <span className="text-sm font-bold text-gray-400 uppercase">Navigation</span>
             <button onClick={() => setMobileMenuOpen(false)}><X className="w-5 h-5" /></button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
           <div className="mb-6">
             <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Priority Graph</h3>
             <TaskTree branches={state.branches} onToggleBranch={toggleBranchStatus} />
           </div>

           {state.knowledgeBank.length > 0 && (
               <div className="flex flex-col h-1/2 min-h-[200px]">
                   <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 flex items-center justify-between">
                       <div className="flex items-center gap-2">
                           <Database className="w-3 h-3" /> Knowledge Bank
                       </div>
                       <span className="text-[10px]">{filteredKnowledge.length} axioms</span>
                   </h3>
                   <div className="relative mb-2">
                       <input 
                         type="text" 
                         placeholder="Filter..." 
                         value={kbFilter}
                         onChange={(e) => setKbFilter(e.target.value)}
                         className="w-full bg-colossus-900 border border-colossus-700 rounded text-xs py-1 px-2 pl-7 focus:outline-none focus:border-colossus-accent text-gray-300"
                       />
                       <Search className="w-3 h-3 text-gray-500 absolute left-2 top-1.5" />
                   </div>
                   <div className="space-y-2 overflow-y-auto flex-1 pr-1">
                       {filteredKnowledge.map(fact => (
                           <div key={fact.id} className="bg-colossus-900/50 p-2 rounded border border-colossus-700/50 text-[10px] text-gray-400">
                               <div className="flex justify-between mb-1">
                                   <span className="text-colossus-accent font-bold">[{fact.sourceAgent.split(' ')[0]}]</span>
                               </div>
                               <p className="line-clamp-3">{fact.content}</p>
                           </div>
                       ))}
                   </div>
               </div>
           )}
        </div>
        
        {/* Footer Stats */}
        <div className="p-4 border-t border-colossus-700 bg-colossus-900/50">
          <div className="flex justify-between text-xs mb-2 text-gray-400 font-mono">
             <span>SYSTEM LOAD</span>
             <span>ACTIVE</span>
          </div>
          <div className="h-1.5 w-full bg-colossus-700 rounded-full overflow-hidden">
            {state.isActive && (
                <div className="h-full bg-colossus-accent animate-pulse w-full origin-left"></div>
            )}
          </div>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div className="flex-1 flex flex-col min-w-0 h-[calc(100vh-3.5rem)] md:h-screen">
        {/* Input Header */}
        <div className="min-h-[5rem] md:h-20 border-b border-colossus-700 bg-colossus-800/50 backdrop-blur-sm flex flex-col md:flex-row items-stretch md:items-center px-4 md:px-6 gap-3 md:gap-4 py-3 md:py-0 z-10">
          <div className="flex-1 relative">
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !state.isActive && handleStartResearch()}
              placeholder="Enter complex objective..."
              className="w-full bg-colossus-900 border border-colossus-700 rounded-md px-4 py-2.5 pl-4 text-sm focus:outline-none focus:border-colossus-accent text-gray-100 placeholder-gray-600 transition-colors"
              disabled={state.isActive}
            />
          </div>
          
          {state.isActive ? (
               <button
                onClick={handleEmergencyStop}
                className="h-10 px-4 md:px-6 rounded-md font-medium text-sm flex items-center justify-center gap-2 transition-all bg-red-900/80 text-red-200 hover:bg-red-800 border border-red-700/50 w-full md:w-auto"
              >
                <Square className="w-4 h-4 fill-current" />
                HALT
              </button>
          ) : (
              <button
                onClick={handleStartResearch}
                disabled={!userInput || !state.isPyodideReady}
                className={`h-10 px-4 md:px-6 rounded-md font-medium text-sm flex items-center justify-center gap-2 transition-all w-full md:w-auto ${
                  !state.isPyodideReady
                    ? 'bg-colossus-700 text-gray-500 cursor-not-allowed' 
                    : 'bg-colossus-accent text-colossus-900 hover:bg-cyan-300 shadow-lg shadow-colossus-accent/10'
                }`}
              >
                <Play className="w-4 h-4" />
                INITIATE
              </button>
          )}
        </div>

        {/* Content Split */}
        <div className="flex-1 flex overflow-hidden relative">
          
          {/* Center: Research Feed */}
          <div className="flex-1 flex flex-col border-r border-colossus-700 md:max-w-4xl w-full">
             <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6 md:space-y-8 custom-scrollbar" ref={scrollRef}>
               {!state.isActive && state.branches.length === 0 && (
                 <div className="h-full flex flex-col items-center justify-center text-gray-600 gap-4 px-6 text-center">
                    <Atom className="w-12 h-12 md:w-16 md:h-16 opacity-20 animate-spin-slow" />
                    <p className="text-sm font-mono">AWAITING COMPLEX DIRECTIVE</p>
                    <p className="text-xs text-gray-700 max-w-md leading-5">
                        Colossus v6.1 Scheduler Online.
                    </p>
                 </div>
               )}

               {state.branches.map((branch) => (
                   <div key={branch.id} className={`space-y-6 transition-opacity duration-500 ${branch.status === 'paused' ? 'opacity-50 grayscale-[0.5]' : 'opacity-100'}`}>
                       {branch.tasks.map(task => task.result && (
                           <div key={task.id} className="animate-fade-in-up group">
                               <div className="flex items-center gap-2 md:gap-3 mb-2 flex-wrap">
                                   <span className={`px-2 py-1 rounded text-xs font-mono ${branch.status === 'paused' ? 'bg-gray-800 text-gray-500' : 'bg-colossus-700 text-gray-400'}`}>{branch.name}</span>
                                   <span className="text-colossus-accent font-bold text-sm">{task.assignedTo}</span>
                                   {task.priority > 8 && (
                                        <span className="text-[10px] bg-red-900/50 text-red-400 px-1.5 py-0.5 rounded border border-red-700">CRITICAL</span>
                                   )}
                               </div>
                               
                               <div className="prose prose-invert prose-sm max-w-none text-gray-300 bg-colossus-800/30 p-4 md:p-6 rounded-lg border border-colossus-700/50 shadow-xl break-words">
                                   <ReactMarkdown>{task.result}</ReactMarkdown>
                                   
                                   {task.pythonCode && (
                                       <NotebookCell 
                                          code={task.pythonCode} 
                                          onRun={(code) => handleReRunSimulation(task.id, branch.id, code)}
                                          readOnly={branch.status === 'paused'}
                                       />
                                   )}

                                   {task.experimentSpec && <SpecViewer spec={task.experimentSpec} />}

                                   {task.groundingUrls && task.groundingUrls.length > 0 && (
                                       <div className="mt-4 pt-4 border-t border-gray-700/50">
                                           <p className="text-xs font-bold text-gray-500 mb-2">References:</p>
                                           <ul className="list-disc list-inside text-xs text-blue-400 space-y-1">
                                               {task.groundingUrls.map((url, idx) => (
                                                   <li key={idx} className="truncate hover:text-blue-300">
                                                       <a href={url} target="_blank" rel="noreferrer">{url}</a>
                                                   </li>
                                               ))}
                                           </ul>
                                       </div>
                                   )}
                               </div>
                           </div>
                       ))}
                   </div>
               ))}

               {state.finalSynthesis && (
                 <div className="border-t-4 border-colossus-accent pt-8 mt-12 pb-20">
                    <h2 className="text-xl md:text-2xl font-bold text-white mb-6 flex items-center gap-3">
                      <Atom className="w-6 h-6 text-colossus-accent" />
                      Final Research Synthesis
                    </h2>
                    <div className="prose prose-invert max-w-none text-gray-200 bg-gradient-to-b from-colossus-800 to-colossus-900 p-4 md:p-8 rounded-xl border border-colossus-600 shadow-2xl break-words">
                      <ReactMarkdown>{state.finalSynthesis}</ReactMarkdown>
                    </div>
                 </div>
               )}
             </div>
          </div>

          {/* RIGHT PANEL (Viz & Logs) - Drawer on Mobile */}
          {/* Mobile Overlay */}
          {mobileDataOpen && (
              <div className="fixed inset-0 bg-black/80 z-30 md:hidden backdrop-blur-sm" onClick={() => setMobileDataOpen(false)} />
          )}

          <div className={`
              fixed inset-y-0 right-0 z-40 w-4/5 max-w-md bg-colossus-900 border-l border-colossus-700 transform transition-transform duration-300 ease-in-out flex flex-col
              md:relative md:translate-x-0 md:w-96 md:flex md:z-auto
              ${mobileDataOpen ? 'translate-x-0 shadow-2xl' : 'translate-x-full'}
          `}>
             {/* Mobile Close Button */}
             <div className="flex items-center justify-between md:hidden p-4 border-b border-colossus-700">
                 <span className="text-sm font-bold text-gray-400 uppercase">Data & Logs</span>
                 <button onClick={() => setMobileDataOpen(false)}><X className="w-5 h-5" /></button>
             </div>

             <div className="h-1/2 p-4 border-b border-colossus-700 flex flex-col min-h-[250px]">
               <SimulationViewer 
                 data={simData} 
                 scenarios={simScenarios}
                 title={simTitle}
                 isActive={state.isActive} 
               />
             </div>
             <div className="h-1/2 p-4 flex-1 overflow-hidden flex flex-col min-h-[250px]">
               <LogStream logs={state.logs} />
             </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default App;
